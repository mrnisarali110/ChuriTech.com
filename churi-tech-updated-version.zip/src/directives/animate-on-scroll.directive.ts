
import { Directive, ElementRef, OnInit, inject, Input, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appAnimateOnScroll]',
})
export class AnimateOnScrollDirective implements OnInit {
  private el = inject(ElementRef);
  private renderer = inject(Renderer2);
  @Input('appAnimateOnScroll') animationType = 'fade-in-up'; // e.g., 'fade-in-left'

  ngOnInit() {
    const element = this.el.nativeElement;
    
    // Ensure we have a valid animation type
    let type = 'fade-in-up';
    if (typeof this.animationType === 'string' && this.animationType.trim()) {
      type = this.animationType.trim();
    }

    // Add base class
    this.renderer.addClass(element, 'scroll-animate');
    
    // Split by spaces in case multiple classes are provided and add each token
    const tokens = type.split(/\s+/).filter(t => t.length > 0);
    tokens.forEach(token => {
      this.renderer.addClass(element, token);
    });

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          this.renderer.addClass(element, 'is-visible');
          observer.unobserve(element);
        }
      });
    }, {
      threshold: 0.1, // Trigger when 10% of the element is visible
    });

    observer.observe(element);
  }
}
